cache = {'monitored_processes': []}
